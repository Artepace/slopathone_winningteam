# Winning team - Balanced Career Agent (v1)

This submission is a Career Survival Agent for JiuwenSwarm 0.2.4b3 in single-agent mode (`"mode": "agent"`). It plays the full 48-month simulation through the five official MCP tools only: `new_game`, `observe`, `take_action`, `check_latest_logs` and `show_employee_handbook`.

The approach is steady, balanced growth. The agent first avoids the published failure directions, then builds Skill, Network and Output over the whole run, and keeps Health, Dignity and Wealth sustainable. It decides only from the public handbook and from what the simulation returns during the current run. It contains no event-specific answers, no memorised sequences and no unpublished thresholds.

## Skills
| Skill | Purpose |
|---|---|
| `career-survival-core` | Run loop (start, resume after a context reset, play, ending), priority order, risk rules based on trends and warnings, six-month review handling, time horizon, compact notes. |
| `event-choice-evaluation` | Method for every monthly story event: estimate each choice's effect on the visible statistics, classify it as safe, trade-off or gamble, and choose by priority. |
| `quarterly-planning` | Quarter-end phase: spend the 3 Energy points and choose or skip the main action, using the published action effects and the stage of the run. |

The Skills share one priority order, so a recovery chosen in the quarterly phase is not undone by a gamble in a monthly event. There are no scripts and no reference files, because the design needs only instructions and the official tools.

## Files
- `manifest.json`: team, submission name, mode and the short instruction that is shown to the agent on every call.
- `design/skills_design.md`: how the Skills divide responsibilities and combine into one decision.
- `design/decision_report.md`: the overall decision approach, the information it relies on, the main risks and how it generalises.
- `skills/`: the three Skills above.
- `presentation.mp4`: the English presentation video.

## Status
The design is based on the public handbook and rules. Its results are described in `design/decision_report.md` only to the extent that they have been observed in local runs.
