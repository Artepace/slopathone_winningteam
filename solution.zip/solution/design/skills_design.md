# Skills Design

## Overview
The agent is controlled by three Skills and a short manifest instruction. The manifest instruction is shown to the agent on every model call, so it carries only the rules that must never be lost after a context reset: the tool list, never calling `new_game` when a `session_id` exists, printing `SESSION_ID=<id>` and the ending payload followed by `DONE`, never stopping before the game ends, and the high-level priority. The Skills hold the full decision procedures.

## Skills and responsibilities
### `career-survival-core`
- **Owns:** the whole run. Starting or resuming a game, the observe-decide-act loop, handling a rejected action, the ending, the priority order, the risk rules, the review follow-up, the time horizon and the notes.
- **Information it uses:** the handbook (read once), every statistic returned by `observe`, warnings, the trend between consecutive observations, review grades, and `check_latest_logs` only when recovering after a reset or explaining a warning.
- **Output:** a priority and a list of which dimensions are under pressure. The other two Skills use this as their starting point.

### `event-choice-evaluation`
- **Owns:** every monthly story event.
- **Information it uses:** the current state, the event text, the effects shown in each choice, and the difference between expected and actual changes in earlier turns.
- **Output:** one choice number and a short note. It classifies each option as safe, trade-off or gamble, and picks by the priority order from the core Skill.

### `quarterly-planning`
- **Owns:** the quarter-end phase: the 3 Energy points and the optional main action.
- **Information it uses:** the published action effects, the current state and pressures, the stage of the run (early, middle, final) and whether a review is close.
- **Output:** a plan that covers urgent needs first, spends the rest on growth, and picks a main action that matches the need or none.

## How the outputs combine
1. The core Skill defines the priority order: stay alive, stay balanced, build sustained growth, then accumulate wealth.
2. At each monthly event, the event Skill applies that order to the options.
3. At each quarter end, the quarterly Skill applies the same order to the actions.
4. Compact notes after every action carry the plan across turns and across context resets.

## What the agent does not use
- Any internal package, database, hidden state or evaluation data.
- Event names, memorised sequences or lookup tables.
- Any numerical threshold presented as a simulation rule. The "lower third of the 0 to 10 range" and "two consecutive observations" triggers are the team's own safety margins, and the Skills label them that way.
- Scripts or reference files. None are needed, and none are included.
