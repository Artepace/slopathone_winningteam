---
name: quarterly-planning
description: "Plans the quarter-end phase: how to spend up to 3 Energy points and which main action to take or skip. Use it whenever observe shows the quarterly action phase or lists Energy actions. It uses only the published action effects and adapts to the state and to how far the run has progressed."
---

# Quarterly Planning

At the end of each quarter you get 3 Energy points (unused points are lost) and may take one main action or none. Follow the actions and costs that the interface actually lists. The effects below are the published ones. Anything else you learn from feedback.

## Published effects
Energy actions:
- High-intensity work (2): Output up, Health down, Dignity down.
- Skill learning (2): Skill up, Health down.
- Network maintenance (1): Network up, Dignity up.
- Defuse legacy risk (2): no published direct statistical effect; by its name it targets accumulated legacy risk, so use it when feedback points to building risk and judge its value from later warnings.
- Mental recovery (1): Dignity up.
- Health recovery (1): Health up.
- Prepare report materials (1): Output up, Dignity up.

Main actions:
- Apply for a key project: Output, Skill, Network up.
- Report results to your manager: Output, Network, Dignity up.
- Fight for resources: Output, Network up.
- Apply for rotation: Skill, Network up.
- Showcase results: Output, Dignity up.
- Build a mentorship: Skill, Network up.
- Repair a key relationship: Network, Dignity up.
- Lay low and reduce risk: Health up.

## Steps
1. **Diagnose.** Apply the risk rules from `career-survival-core`. Name the dimension under pressure (if any), the weakest dimension, any warning, and whether a six-month review is close.
2. **Cover urgent needs first.**
   - Health under pressure: Health recovery; consider the main action "Lay low and reduce risk".
   - Dignity under pressure: Mental recovery, Network maintenance or Prepare report materials; consider "Repair a key relationship" or "Showcase results".
   - A warning about hidden or accumulated risk: Defuse legacy risk (2 Energy).
   - Network at or near zero: Network maintenance and a main action that raises Network.
3. **Spend the rest on growth.** Prefer actions that raise a dimension without costing Health or Dignity (Network maintenance, Prepare report materials). Use High-intensity work or Skill learning only when Health and Dignity are not under pressure, and pair them with a recovery action in the same or the next quarter.
4. **Choose the main action to fit the need.**
   - Stable and balanced: the action that raises most of the dimensions you want, such as "Apply for a key project" for broad growth.
   - Weak Skill: "Apply for rotation" or "Build a mentorship".
   - Weak Output before a review or promotion window: "Showcase results" or "Report results to your manager".
   - Health or risk pressure: "Lay low and reduce risk".
   - Nothing fits: take no main action.
5. **Use the Energy.** Spend all 3 points unless a remaining action would hurt a dimension that is under pressure. Do not repeat the same Health-costing or Dignity-costing action every quarter.
6. Execute the actions one at a time through `take_action`, read the feedback after each one, and revise the rest of the plan if something changed. Notes stay under 300 characters, for example: `Q5 Dignity low: Mental recovery + Network, main: Repair relationship`.

## Stage of the run
- Early quarters: favour Skill and Network, which compound slowly. Keep Health and Dignity out of pressure.
- Middle quarters: turn capability into Output and promotion readiness, with recovery whenever pressure appears.
- Final quarters: choose actions whose effect lands before month 48. Skip slow investments that cannot pay off, and do not run Health or Dignity down at the end.

## If the interface differs
Costs, effects or the option list may differ from this page. Follow what the interface shows and use the same diagnose-then-plan logic.
