# Decision Report

## 1. Approach
The task is a balance-and-timing problem under incomplete information. The ending covers career level, total wealth, health and dignity, skill, risk control and network, and a run can end early in several ways. Our approach, in priority order:
1. **Stay in the game.** Avoid every published failure direction; clean up hidden risk when the game warns about it; never spend money when Wealth is low.
2. **Win the first promotion early.** Level and salary depend on it, and two weak half-year reviews end the run.
3. **Build sustained growth** in Skill, Network and Output, with Health and Dignity kept sustainable.
4. **Accumulate Wealth** through level and review bonuses.

## 2. Information used
- The public handbook (read once) and the published rules: salary by level, quarterly actions, review grades, failure directions and ending dimensions.
- Each `observe` result: statistics, the monthly news text (including HR comments about risk), the event and its choices.
- The costs and effects listed for each quarter-end action.
- The agent's own one-line notes, recovered through `check_latest_logs` after a context reset.

## 3. What our local runs taught us
We ran several local games on the development dataset with different versions (a simple three-Skill version, longer versions with more procedures, and a version with an extra promotion-focus rule).
- **Simple beat complex.** The simple version averaged far higher than versions with long reasoning procedures or extra focus rules, which slowed growth or removed useful actions.
- **Getting dismissed decides the score.** Runs ended early in two ways: dismissal after two weak half-year reviews, and a trust crisis after a second blow-up of accumulated risk. Every run without an early first promotion ended in dismissal; every completed run was promoted early.
- **Careful is not free.** Slow, thorough event options sometimes cost Output or Network; options that postponed or skipped fixes tended to come before risk warnings. The Skills therefore choose between equally safe options by protecting Output and Network, and drop postponing options only while risk is flagged.
- **One avoidable failure.** In one run an optional payment early in the game emptied the agent's wealth and ended the run. A money guard was added.
- **A forgotten warning.** An agent that only checked the current month's risk comment skipped a clean-up. The Skills now keep a risk flag in every note and look at the worst flag since the last quarter-end.
- **Wording matters for this model.** Rules are written as ordered, explicit steps and the critical ones are repeated in the manifest.

## 4. Risks and mitigations
- **Hidden risk is invisible.** Mitigation: a fixed clean-up rule tied to the news comments, kept through a flag in the notes.
- **Clean-up costs growth.** Mitigation: serious warnings are always acted on; mild ones only when they repeat.
- **Slow first promotion.** Mitigation: Output and Network actions in every normal quarter before the first promotion, and no events that cost them when a safer-equal option exists.
- **Event luck between runs.** Mitigation: versions are compared over repeated runs; survival is judged before the average.
- **Model limits.** Mitigation: short Skills with explicit steps and no dependence on one model version's quirks.

## 5. Generalisation
Nothing depends on event titles, event order, event text or numbers from our runs. Each decision uses the current statistics, the news text and the effects shown on screen. The only numeric margins (Health or Dignity in the lower third of the 0 to 10 range, Wealth of 3 or below, Network of 0 or 1) are labelled as our own. If action costs, effects or lists change, the Skills tell the agent to use what the interface shows.

## 6. Validation status
This version has not yet been evaluated; it is a revision of the simple version with guards for failures we observed. This report claims only what has been observed, and no result is assumed in advance.
