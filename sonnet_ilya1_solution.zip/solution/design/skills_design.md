# Skills Design

## Overview
The agent is controlled by three Skills and a manifest instruction. The manifest instruction is shown on every model call, so it carries the rules that must never be lost after a context reset: the tool list, never calling `new_game` when a `session_id` exists, observing after each action, printing the session id and the ending payload followed by `DONE`, and two guards (low Wealth, risk warnings). The Skills hold the full procedures. The design keeps the Skills short, with ordered steps and one priority list, because the designated model is a small, fast model that follows explicit rules better than long reasoning procedures.

## Skills and responsibilities
### `career-survival-core`
- **Owns:** the whole run: starting or resuming one game, the observe-decide-act loop, rejected actions, the ending, the priority order, the risk rules, the money guard, the risk flag, review follow-up, time horizon and notes.
- **Information it uses:** the handbook (read once), every statistic and the news text from `observe`, review grades, and `check_latest_logs` only when recovering after a reset.
- **Output:** a priority list, the dimensions under pressure, and a `risk:none|mild|serious` flag written into every note. The flag is the agent's memory of risk between turns.

### `event-choice-evaluation`
- **Owns:** every monthly story event.
- **Information it uses:** the current state, the event text, the effects each choice states or implies, and the risk flag in the notes.
- **How it decides:** options that hide a problem, mislead someone, blame unfairly or skip a check are removed; when Wealth is low, options that cost money are removed; while risk is flagged, options that postpone, loosen or skip a fix are removed; before a review, between equally safe options the one that does not lower Output or Network is taken; then it picks the best long-term value and avoids gambles.

### `quarterly-planning`
- **Owns:** the quarter-end phase: the 3 Energy points and the optional main action.
- **Information it uses:** the actions, costs and effects listed on screen, the statistics, and the worst risk flag in the notes since the previous quarter-end.
- **How it decides:** a serious risk flag forces the risk-lowering Energy action and main action; repeated mild flags trigger one clean-up; before the first promotion every quarter keeps Output and Network actions; recoveries are never bought for a statistic at its maximum; Skill learning and High-intensity work are used only when Health and Dignity are safe and risk is calm.

## How the outputs combine
1. The core Skill reads the news, sets the risk flag and defines the priorities.
2. At each event, the event Skill applies them to the options. At each quarter-end, the quarterly Skill applies them to the actions.
3. Compact notes after every action carry the plan, the statistics and the risk flag across turns and context resets.

## What the agent does not use
- Any internal package, database, hidden state or evaluation data.
- Event names, memorised sequences or lookup tables.
- Any number presented as a simulation rule. The margins used (lower third of the 0 to 10 range, Wealth of 3 or below on the screen) are the team's own cautions and the Skills label them that way. Action effects are read from the screen each time.
- Scripts, reference files or multiple agents.
