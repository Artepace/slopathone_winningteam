# Winning team - Career Survival Agent (career-agent-sonnet1)

This submission is a Career Survival Agent for JiuwenSwarm 0.2.4b3 in single-agent mode (`"mode": "agent"`). It plays the full 48-month simulation through the five official MCP tools only: `new_game`, `observe`, `take_action`, `check_latest_logs` and `show_employee_handbook`.

The approach is steady, balanced growth with a few explicit guards. The agent first avoids the published failure directions, wins its first promotion early, then builds Skill, Network and Output over the whole run while keeping Health, Dignity and Wealth sustainable. It decides only from the public handbook and from what the simulation returns during the current run. It contains no event-specific answers, no memorised sequences and no unpublished thresholds.

## Skills
| Skill | Purpose |
|---|---|
| `career-survival-core` | Run loop (start, resume after a context reset, play, ending), priority order, risk rules, a money guard, the risk flag read from the news text, review handling, time horizon, compact notes. |
| `event-choice-evaluation` | Method for every monthly story event: estimate each choice's effect, drop options that hide problems, spend money when Wealth is low, or postpone fixes while risk is flagged, then choose by priority. |
| `quarterly-planning` | Quarter-end phase: risk clean-up after serious warnings, Output and Network actions before the first promotion, recovery where needed, and the main action. |

The Skills share one priority order, so a recovery chosen in the quarterly phase is not undone by a gamble in a monthly event. There are no scripts and no reference files, because the design needs only instructions and the official tools.

## Files
- `manifest.json`: team, submission name, mode and the instruction shown to the agent on every call.
- `design/skills_design.md`: how the Skills divide responsibilities and combine into one decision.
- `design/decision_report.md`: the decision approach, the information it relies on, the main risks and how it generalises.
- `skills/`: the three Skills above.
- `presentation.mp4`: the English presentation video (added to the final package).

## Status
The design is based on the public handbook and rules. Its results are described in `design/decision_report.md` only to the extent that they have been observed in local runs.
