---
name: quarterly-planning
description: "Plans the quarter-end phase: how to spend up to 3 Energy points and which main action to take or skip. Use it whenever observe shows the quarterly action phase or lists Energy actions. It uses only the published action effects, cleans up hidden risk after warnings, and adapts to the state and to how far the run has progressed."
---

# Quarterly Planning

At the end of each quarter you get 3 Energy points (unused points are lost) and may take one main action or none. Follow the actions, costs and effects that the interface actually lists on screen; they can differ from this page. The effects below are the published ones. Anything else you learn from feedback.

## Published effects
Energy actions:
- High-intensity work (2): Output up, Health down, Dignity down. If the listed effects also raise hidden risk, never use it.
- Skill learning (2): Skill up, Health down.
- Network maintenance (1): Network up, Dignity up.
- Defuse legacy risk (2): lowers hidden risk (see the listed effects).
- Mental recovery (1): Dignity up.
- Health recovery (1): Health up.
- Prepare report materials (1): Output up, Dignity up.

Main actions:
- Apply for a key project: Output, Skill, Network up.
- Report results to your manager: Output, Network, Dignity up.
- Fight for resources: Output, Network up.
- Apply for rotation: Skill, Network up.
- Showcase results: Output, Dignity up.
- Build a mentorship: Skill, Network up.
- Repair a key relationship: Network, Dignity up.
- Lay low and reduce risk: Health up; its listed effects show whether it also lowers hidden risk.

## Steps
1. **Diagnose.** Apply the risk rules from `career-survival-core`. Name the dimension under pressure (if any), the weakest dimension, the worst risk flag in your notes since the previous quarter-end (including this month), and whether a six-month review is close.
2. **Risk clean-up first.**
   - `risk:serious` since the last quarter-end: take Defuse legacy risk AND make Lay low and reduce risk the main action. This is not optional and growth never replaces it.
   - `risk:mild` is the worst flag both this quarter and the previous quarter, and the previous quarter had no clean-up: take Defuse legacy risk once. (A single mild quarter needs nothing.)
   - A blow-up message has happened: take Defuse legacy risk AND the main action Lay low and reduce risk every quarter until two quarters in a row show no risk comment.
   - The clean-up comes first and uses its Energy; spend what is left on step 3 and step 4 (for example one report or recovery point after a 2-point Defuse).
3. **Cover other urgent needs.**
   - Health under pressure: Health recovery.
   - Dignity under pressure: Mental recovery, Network maintenance or Prepare report materials; consider "Repair a key relationship" or "Showcase results".
   - Network at or near zero: Network maintenance and a main action that raises Network.
   - Never buy a recovery for a statistic that is already at 10.
4. **Spend the rest on growth, with Output and Network first.** The default quarter is Prepare report materials + Network maintenance + one more 1-point action (Health recovery if Health is below 10, otherwise a second Prepare report materials or Network maintenance), with the main action "Apply for a key project". Until you have your first promotion, every quarter that is not a risk clean-up quarter keeps both Prepare report materials and Network maintenance. After a C or D review, keep them too.
5. **Use Skill learning and High-intensity work carefully.** Use them only when Health and Dignity are not under pressure, no risk flag is `serious`, and the listed effects do not raise hidden risk. If Health is below 10 afterwards, recover it in the same or the next quarter. Do not repeat the same Health-costing or Dignity-costing action every quarter. When Skill is the weakest dimension, "Apply for rotation" or "Build a mentorship" as the main action costs no Energy.
6. **Choose the main action to fit the need.**
   - Stable and balanced: "Apply for a key project" for broad growth.
   - Weak Skill: "Apply for rotation" or "Build a mentorship".
   - Weak Output before a review or promotion window: "Showcase results" or "Report results to your manager".
   - Risk clean-up or Health pressure: "Lay low and reduce risk".
   - Nothing fits: take no main action.
7. **Use the Energy.** Spend all 3 points unless a remaining action would hurt a dimension that is under pressure. An action may be taken twice in a quarter if it is still listed. Do not repeat a plan that the statistics show did not work: if a statistic you paid for did not rise, pay for a different one.
8. Execute the actions one at a time through `take_action`, then `observe`, and revise the rest of the plan if something changed. Notes stay under 300 characters and keep the core format, for example: `Q5 M15 L2 H6 D8 N4 O3 | risk:none | plan: report + network + health, main: key project`.

## Stage of the run
- Early quarters: favour Output, Network and Skill, which compound slowly. Keep Health and Dignity out of pressure.
- Middle quarters: turn capability into Output and promotion readiness, with recovery whenever pressure appears.
- Final quarters: choose actions whose effect lands before month 48. Skip slow investments that cannot pay off, do not run Health or Dignity down at the end, and in the last quarter-end (month 48, after the final review) raise Health and Dignity toward 10 first, then take any risk clean-up that applies, then Network maintenance. Main action there: Lay low and reduce risk if a clean-up applies, otherwise "Report results to your manager".

## If the interface differs
Costs, effects or the option list may differ from this page. Follow what the interface shows and use the same diagnose-then-plan logic.
