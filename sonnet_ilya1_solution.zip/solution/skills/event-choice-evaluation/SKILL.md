---
name: event-choice-evaluation
description: "Method for choosing among the options of a monthly story event. Use it every time observe returns a story event with numbered choices, whatever its wording or order. It compares the effects of each choice on the visible statistics and picks the safest option with the best long-term value."
---

# Event Choice Evaluation

Each month has up to three story events. Decide each one from the current state and the effects that the text or the choices describe. Never decide from an event title or from memory of earlier runs.

## Steps
1. **State check.** Using the risk rules in `career-survival-core`, name any dimension under pressure (Health, Dignity, Wealth, Network, or a warning). Note the weakest dimension and any falling trend.
2. **Read every choice fully.** For each one, write down which of Health, Dignity, Skill, Network, Output and Wealth it likely raises or lowers. Use effects shown in the choice first. When none are shown, infer the direction from the wording and mark it uncertain.
3. **Classify each choice.**
   - Safe: protects or improves a core dimension and defers no problem.
   - Trade-off: gains in one dimension at a cost in another.
   - Gamble: secret, shortcut-based, confrontational, luck-dependent or with unclear consequences.
4. **Pick with this order.**
   1. Never pick an option that hides a problem, misleads someone, blames someone unfairly, or skips a required check. If every option does, pick the least harmful.
   2. Money guard: if Wealth is 3 or below (our own margin), drop every option that costs money, unless all do.
   3. If a dimension is under pressure, choose the option that protects it, unless that creates a worse problem elsewhere.
   4. If your last note or the news text says `risk:serious`, or a blow-up has happened, drop options that postpone, loosen or skip a fix, a check or a review, even when they sound reasonable.
   5. In the two months before a half-year review (months 4-5, 10-11, 16-17, 22-23, and so on), when two options are equally safe, take the one that does not lower Output or Network.
   6. Otherwise choose the best long-term value: Skill, Network, sustained Output, and steady Dignity and Health.
   7. Take a gamble only when no dimension is under pressure and the upside is clearly meaningful.
5. **Tie-breakers.** If options look equal, take the one that keeps more future options open. If the effect is unclear, take the more conservative option for Health and Dignity. Prefer the option that does not tell you to hide a problem.
6. `take_action` with the choice number as listed, and a note of under 300 characters in the core format, including the `risk:` flag, the reason and the dimension you expect to move.

## Consistent principles
- Overwork, humiliation and shortcuts often buy short-term Output or Wealth at the cost of Health, Dignity or later risk. The handbook says sustained overwork may create serious risk. Treat such options as costly unless the state is strong and no warning exists.
- Honest communication, reliable delivery and relationship-building tend to support Network, Dignity and long-term standing.
- Doing the careful thing is not free: thorough or slow options can cost Output or Network. Prefer them when risk is present or Health and Dignity are under pressure; otherwise take the option that also protects results.
- A long period of negative Wealth is a public failure direction. Do not accept a repeated drain on Wealth for a small gain elsewhere.
- Do not let one easy win drive three months of choices. Re-check the whole state each time.

## Learning inside the run
After each action, compare the next observation with what you expected. If the result was worse, be more cautious with that kind of choice in later events. If it was better, you may use that kind slightly more. Keep this as a short pattern in your notes, never as a claim about hidden formulas.
