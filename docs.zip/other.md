Quickstart
This page is the supported local development workflow, in order: obtain the competition API key, install the participation repository, configure the local environment, run and inspect a game, and validate a submission before packaging it. Manual command line testing and the list of run artifacts are included at the end as reference.

Simulation overview
A complete run lasts 48 simulated months. Each month, the simulation presents workplace events and the agent selects a response. At the end of each quarter, the agent receives 3 Energy points for quarterly energy actions and may select one quarterly main action. A formal performance review is held every six months.

Story choices affect current statistics and may affect later events. Quarterly actions have a longer-term effect on career development. Risks may accumulate over several months before their consequences become visible. Participants should therefore evaluate decisions over the full 48-month run rather than optimise only the next event. See Public handbook, Public rules, and Failure and endings for the published game information.

1. Obtain the competition API key
Follow the procedure in Competition API key. The organisers issue the key by email after verifying the team’s preliminary design and Skills documents.

The issued key is limited to the designated competition model, a maximum of USD 50 in credit, and the competition week. Enter only the API_BASE, API_KEY, and MODEL_NAME values supplied by the organisers in the local environment file. Do not configure OpenRouter provider routing locally; official scoring applies organiser-controlled routing (see Competition API key).

Before using the competition API key, read Competition API key and submit the preliminary design documents required for verification.

2. Install the participation repository
Clone the official participation repository from GitHub and install its dependencies:

make sync
This prepares the project environment, including JiuwenSwarm and the career-emulator-engine package. The engine installation includes the MCP component and the career-emulator-techarena development dataset. See Competition packages for the separate roles of the two PyPI packages.

Important

The required JiuwenSwarm version is exactly 0.2.4b3. The official participation repository pins this version, so use make sync rather than installing, upgrading, downgrading, or replacing JiuwenSwarm separately. If a local environment contains another version, re-run make sync and test again with 0.2.4b3 before relying on the results.

Only single-agent mode may be used. Keep "mode": "agent" in solution/manifest.json. Do not use JiuwenSwarm team mode for development runs intended to represent the submitted agent, and do not submit a manifest with "mode": "team".

3. Configure the local environment
Copy the example environment file and enter the API values supplied by the organisers:

cp .env.example .env
# Set API_BASE, API_KEY, and MODEL_NAME from the organiser email only.
# Do not add OpenRouter provider / order / only preferences.
make setup
make setup creates the JiuwenSwarm named instance career_emu and writes the engine MCP configuration and model settings into that instance. Only API_BASE, API_KEY, and MODEL_NAME from the repository .env are overlaid onto the instance environment.

Start the instance in a separate terminal:

make start-jiuwen
Instance status can be checked with:

uv run jiuwenswarm-start --list
The command reports the ports assigned to the instance. The final port is the JiuwenSwarm web interface. See Configuring the track MCP server for the MCP configuration this setup creates.

4. Run and inspect a game
Copy example_submission_structure/ to solution/ at the repository root, then play one game with that directory. solution/ is the working copy. It is not part of the clone.

make play
presentation.mp4 is not required for this local run. You can play before the video is recorded. The final ZIP still requires that file, and the validation command below reports it when it is missing.

Read the score from the latest completed run:

make score
This is the score of one local run only. quantitative_score is the 0–100 career outcome. Official live play is the mean of three runs’ quantitative_score values. That mean is multiplied by 0.80 once, alongside document design quality (10%) and token efficiency (10%). competition_partial_score is quantitative_score × 0.7 and is not used in that formula. The team’s Stage 1 score is its highest valid automated version score; only the top ten teams after Stage 1 advance to expert review, where the final competition score is 70% Stage 1 score plus 30% expert review score (see Competition rules and fair play). A single local score is therefore neither an official live play score, nor an automated version score, nor the team’s final score.

Create a readable Markdown replay from the latest run events:

make replay
5. Validate and prepare the submission
Validate the submission before packaging it:

uv run python -m career_sim_runner validate --submission solution
This command checks the submission directory only. It does not contact JiuwenSwarm, so a stopped instance does not fail the command. It fails when manifest.json sets a mode other than "agent", including "mode": "team". Local validation is a development aid. It does not replace the complete submission requirements in Submission requirements.

Prepare the final ZIP archive according to Submission requirements. The required design/ and skills/ directories must both be present, and so must solution/presentation.mp4. The validation command reports a missing video, an empty video, a placeholder team name, and a prohibited run mode. Before packaging, confirm that the final test used JiuwenSwarm 0.2.4b3, and that every deliverable in the final ZIP — the manifest.json instruction, README.md, the spoken presentation, both design documents, and every Skill — is written entirely in English. A submission missing a required folder or file, using the prohibited team mode, or containing a non-English deliverable is invalid and may receive no score.

Manual command line testing
The rules may also be tested manually without an agent. Install the engine with its MCP component, load the development dataset, and start the command line interface:

pip install "career-emulator-engine[mcp]"
career-emulator-engine update --source distribution --split dev
career-emulator-engine play
Within the command line interface:

enter a number to select the corresponding choice;

enter handbook to display the public employee handbook;

enter logs to display the current session log;

enter quit to end the session.

Manual command line use is for familiarisation and testing. An evaluated agent must interact with the simulation through the official MCP tools described in Configuring the track MCP server and Competition rules and fair play.

Run artifacts
Each run writes output under .career_sim_runner/career_emu/:

.career_sim_runner/career_emu/
  active_install.json        # currently mounted submission
  career_emulator.sqlite3    # shared state database
  emulator_logs/             # Career Emulator logs
  outputs/
    <submission_name>/
      <timestamp>/
        transcript-*.log     # conversation transcript
        events-*.jsonl       # structured event stream
        score_report.json    # ending score report
These files are outputs of local runs. Participants must not modify them in order to alter a result, and must not use the local database as a substitute for the official MCP interface.

Competition packages
Career Survival Agent is distributed through two separate PyPI packages. They have different purposes and should not be confused. This page first describes those two simulation packages and how to load the development dataset, and then states the required agent platform, which is not one of the two simulation packages.

career-emulator-engine
career-emulator-engine is the simulation engine. It contains the game logic and state handling, the command line program, and the MCP server used by agents.

It provides two commands:

career-emulator-engine: load a dataset and play or test the simulation from the command line.

career-emulator-engine-mcp: start the MCP server through which an agent starts a game, observes state, and takes actions.

Install the engine with the MCP component as follows:

pip install "career-emulator-engine[mcp]"
Installing the engine also installs a compatible version of the data package as a dependency.

career-emulator-techarena
career-emulator-techarena is the data package. It contains the development validation dataset: the public events and related configuration with which participants develop and test their agents.

The data package does not contain a playable engine and does not provide the competition commands by itself. It is normally installed automatically when career-emulator-engine is installed. Install it separately only when the dataset package is required without explicitly managing the engine dependency:

pip install career-emulator-techarena
Loading the development dataset
After installing the engine, load the packaged development dataset as follows:

career-emulator-engine update --source distribution --split dev
career-emulator-engine play
For MCP use, start the official server with:

career-emulator-engine-mcp --help
Participants using the official participation repository should normally use its dependency and setup commands rather than installing these packages into the system Python environment. See Quickstart.

Development and evaluation data
The career-emulator-techarena package published for participants contains the development (dev) validation dataset. It is provided so that teams can build, test, and compare agent designs locally.

The dataset and parameters used for official evaluation are not published in the participant package and are not available for local inspection. Behaviour, thresholds, event composition, and results in the development dataset must not be assumed to be identical during official evaluation.

Package contents are not a participant interface. Participants must access the simulation through the public CLI and MCP interfaces and must not inspect or extract the packaged data in order to derive internal rules. The binding restrictions are stated in Competition rules and fair play.

Required agent platform: JiuwenSwarm
JiuwenSwarm is the agent platform, not one of the two simulation packages above. The required version is JiuwenSwarm 0.2.4b3 (also written as 0.2.4.beta3 in the repository dependency pin; both spellings normalise to the same version). Participants must use exactly this version. Do not upgrade, downgrade, replace, or separately install another JiuwenSwarm version, and do not override the version pinned by the official participation repository. Behaviour observed with another version is not accepted as a substitute for testing with 0.2.4b3.

Only JiuwenSwarm’s single-agent mode may be used. Submissions must set "mode": "agent" in manifest.json. The team mode is prohibited: do not set "mode": "team", do not run an evaluated agent through JiuwenSwarm team execution, and do not design Skills that require a leader with multiple teammate agents. See Competition rules and fair play for the binding rule and Submission requirements for the manifest requirements.

Configuring the track MCP server
The agent interacts with the simulation through the MCP server provided by career-emulator-engine. This page describes the supported configuration and the official tool interface.

Configuration in JiuwenSwarm
Use JiuwenSwarm version 0.2.4b3 only, in single-agent (agent) mode. The JiuwenSwarm team mode is prohibited for this competition, including when testing a design that will be submitted. Install the version pinned by the official participation repository; do not substitute another version.

In the official participation repository, install the dependencies and configure the environment:

make sync
cp .env.example .env
# Enter API_BASE, API_KEY, and MODEL_NAME as instructed in the API key email.
# Do not add OpenRouter provider routing settings.
make setup
make setup performs the following actions:

Creates a JiuwenSwarm named instance called career_emu.

Writes career-emulator-engine-mcp into the instance MCP configuration.

Copies API_BASE, API_KEY, and MODEL_NAME from .env into the instance environment.

Official scoring uses the designated model under organiser-controlled upstream routing. See Competition API key and Competition rules and fair play.

Start the instance with:

make start-jiuwen
After startup, use the JiuwenSwarm web interface on the port assigned to the career_emu instance.

Connecting another MCP client
During development, another MCP client may connect to the official server through its standard input/output transport:

career-emulator-engine-mcp
Use the server executable provided by the installed career-emulator-engine package. Do not replace it with a modified server, connect directly to the simulation database, or call internal package functions as a substitute for the MCP interface.

Available MCP tools
The official MCP interface provides five tools:

new_game(): start a new simulation and return a session_id.

observe(session_id): return the current state, event, and choices.

take_action(session_id, choice, notes): apply a selected choice and record an agent note.

check_latest_logs(session_id, count=10): return recent log entries for the session.

show_employee_handbook(): return the public employee handbook.

The server also exposes the session log through the logs://{session_id} resource where that resource is supported by the MCP client.

These tools are the complete official agent interface for evaluated runs. Restrictions on direct package inspection and hard-coded dataset knowledge are stated in Competition rules and fair play.

Public handbook
This page summarises the public employee handbook: what information is public, the time structure, the level system, and the visible statistics. It states the information that participants may rely on when designing a long-term strategy. It does not publish every internal condition used by the simulation. The published action effects, salary, performance, and promotion rules are in Public rules; failure directions and ending evaluation are in Failure and endings.

Public and non-public information
The public information includes:

the ten-level career structure and six-month promotion windows;

the visible statistics and their general meanings;

the quarterly Energy actions and quarterly main action;

the 48-month time structure;

the monthly salary schedule and performance grade meanings;

the general directions of the principal failure conditions.

The following information is not published:

exact promotion and performance formulas;

exact thresholds and counters for failure conditions;

hidden-risk conditions and consequences;

event composition, trigger probabilities, and evaluation parameters.

Participants must design for incomplete information. Feedback returned during a run may indicate increasing risk, but it does not disclose the underlying formula or the distance to an unpublished threshold.

Time structure
A complete run lasts 48 months. By default, a month contains up to three story events. The normal sequence is:

Advance the month and pay the base salary for the current level.

Present the month’s story events.

Resolve the events through the available choices.

At the end of a quarter, enter the quarterly action phase.

Spend up to 3 Energy points on energy actions.

Select one quarterly main action, or select no main action.

Settle statistics and issue any applicable warnings.

Every six months, conduct a performance review and settle the associated bonus.

Monthly choices primarily determine immediate outcomes. Quarterly actions have greater influence on the longer-term career trajectory, while the six-month review evaluates performance over a longer period.

Level system
The organisation has ten levels, from L1 to L10. A promotion window opens every six months. Higher levels have higher overall requirements. Exact promotion thresholds are not published.

Levels at a glance
Level

Name

Public description

L1

Junior engineer

Carries out tasks with clear guidance.

L2

Engineer

Owns modules independently.

L3

Senior engineer

Owns core modules, with growing technical responsibility.

L4

Staff engineer

Works on critical systems with major project impact.

L5

Principal / team lead

Leads a subsystem or small team.

L6

Senior principal / tech lead

Leads large programmes or sets technical direction.

L7

Director of engineering

Department-level technical strategy.

L8

Senior director

Cross-department technical planning.

L9

Distinguished fellow / architecture committee

Company-wide technical influence.

L10

Chief architect / fellow

Makes company-wide technical decisions over a long horizon.

Visible statistics
Decisions should be based on the statistics returned through the official interface. The visible statistics do not represent every internal condition, but they are the principal public indicators of career development and risk.

Visible statistics
Key

Range

Meaning

Health

0 to 10

Physical condition. Sustained overwork may create serious risk.

Dignity

0 to 10

Organisational standing and self-respect. Sustained low values are dangerous.

Skill

0 and above

Accumulated professional capability.

Network

0 and above

Professional relationships within the organisation.

Level

L1 to L10

Current career level.

Output

0 and above

Visible work results available for organisational evaluation.

Wealth

Unbounded

Accumulated wealth; it may become negative.

Energy

0 to 3

Quarterly action budget, available at the end of a quarter.

CurrentLevelDuration

0 and above

Number of months spent at the current level.

Public rules
This page states the published rules governing salary, quarterly resources, performance, and promotion windows, organised by cadence: monthly, quarterly, and every six months. Exact internal formulas and thresholds are not published.

Salary
Monthly base salary depends on the current level. Higher levels receive a higher monthly payment.

Monthly base salary
Level

Wealth / month

L1

0.3

L2

0.4

L3

0.5

L4

0.7

L5

1.0

L6

1.5

L7

2.3

L8

3.6

L9

5.7

L10

9.1

Quarterly Energy actions
At the end of each quarter, the agent receives 3 Energy points. Energy may be spent on the actions below until the points are exhausted or the agent ends the phase. Unused Energy does not carry over to the next quarter.

Energy actions
Action

Cost

Public effect

High-intensity work

2

Output +, Health -, Dignity -

Skill learning

2

Skill +, Health -

Network maintenance

1

Network +, Dignity +

Defuse legacy risk

2

No published direct statistical effect

Mental recovery

1

Dignity +

Health recovery

1

Health +

Prepare report materials

1

Output +, Dignity +

Quarterly main action
In addition to Energy actions, the agent may select one main action per quarter, or select no main action. The main action represents the principal career focus for that quarter.

Main actions
Action

Public effect

Apply for a key project

Output +, Skill +, Network +

Report results to your manager

Output +, Network +, Dignity +

Fight for resources

Output +, Network +

Apply for rotation

Skill +, Network +

Showcase results

Output +, Dignity +

Build a mentorship

Skill +, Network +

Repair a key relationship

Network +, Dignity +

Lay low and reduce risk

Health +

Performance review
A formal performance review takes place every six months. Performance is determined by multiple factors. The grade meanings and bonus directions are public; the exact evaluation formula is not.

Performance grades
Grade

Meaning

Half-year bonus

Public interpretation

S

Exceptional

3 × monthly base

Performance substantially above expectations.

A

Strong

2 × monthly base

Performance above the normal expected level.

B

Solid

1 × monthly base

Performance meets the normal expected level.

C

Weak

0.25 × monthly base

Performance below expectations; corrective action is advisable.

D

Very weak

No bonus

Performance materially below expectations.

Promotion windows
A promotion window opens every six months. Promotion assessment considers factors including Skill, Network, and Output. Requirements increase with level, and the exact thresholds are not published.

Promotion is based on sustained results rather than a single month of unusually strong statistics. Participants should use performance outcomes, visible statistics, and longer-term trends returned during a run to assess progress. No exact distance to promotion is provided.


Failure and endings
A run may end before month 48 if a failure condition is met. If the agent completes all 48 months, the simulation produces an ending evaluation.

Early failure directions
The handbook publishes the general failure directions but not the exact internal thresholds, counters, consecutive-period requirements, or penalties. The principal public risk directions are:

health reaching zero;

dignity remaining at a critically low level;

accumulated hidden risks producing a serious organisational consequence;

repeated low performance;

network remaining at zero for an extended period;

wealth remaining below zero for an extended period;

skill falling materially behind organisational expectations.

These descriptions identify the nature of the risks; they do not state that a single observation of a low value will always cause immediate failure. The exact conditions are not public. Participants should respond to persistent adverse statistics and warning feedback rather than wait for a failure to occur.

Completing the run and ending evaluation
Completing the 48-month simulation does not by itself determine the final competition ranking. The local simulation reports an ending evaluation based on quantitative career outcomes. Official evaluation is performed under the organisers’ competition configuration, and the local result should be used as development feedback rather than treated as a guaranteed final score.

The local report prints quantitative_score on a 0–100 scale. That number is the career outcome. An early exit still receives a quantitative_score from the state at exit. Official live play is the mean of three runs’ quantitative_score values. The 80% weight is applied once, to that mean.

The score data also includes competition_partial_score, which is quantitative_score × 0.7 (maximum 70). It is not shown as the run score. It is not the live play score, and it is not multiplied by 0.80.

Official scoring is defined in Competition rules and fair play. Live play counts for 80% of the version’s automated score, alongside document design quality (10%) and token efficiency (10%). A team’s Stage 1 score is its highest valid automated version score; only the top ten teams after Stage 1 advance to expert review, where the final competition score is 70% Stage 1 score plus 30% expert review score. A single local ending is one development result, not a three-run average.

The quantitative ending reported by the simulation considers the following dimensions:

Quantitative ending dimensions
Dimension

Basis of assessment

Career level

The career level reached by the end of the run.

Total wealth

Wealth accumulated over the 48 months.

Health & dignity

The combined condition indicated by health and dignity.

Professional skill

Skill accumulated over the run.

Risk control

Whether relevant risks remained within acceptable limits.

Workplace network

The state of the agent’s organisational relationships.

The ending report states the quantitative score out of 100 and how much each dimension above contributed to it.

What this means for design
A sound design should avoid persistent weakness in any principal dimension. Maximising one statistic while allowing health, dignity, relationships, or financial stability to deteriorate may result in early termination or a poor ending evaluation. Long-term balance and timely correction are therefore central to the competition task.

Submission requirements
This page defines what participants must submit, first for API-key verification and then as the final evaluated submission. It is organised as: the preliminary submission, the final submission package, the conditions that make a submission invalid, and the checks to run before submitting. The binding conduct rules are in Competition rules and fair play.

Preliminary submission
Before an API key is issued, a team must submit the initial design and Skills documents described in Competition API key. The preliminary submission verifies genuine participation only. It is not scored and is not a substitute for the final submission.

Final submission
Package the final submission as a single ZIP archive containing one top-level solution/ directory. After extraction, the structure must be:

solution/
  manifest.json
  README.md
  presentation.mp4
  design/
    skills_design.md
    decision_report.md
  skills/
    <skill-name>/
      SKILL.md
      script/ (optional)
      reference/ (optional)
    <another-skill-name>/
      SKILL.md
At least one directory under skills/ is required. Each submitted Skill must have its own directory and a SKILL.md file. A Skill may also contain a script/ directory and a reference/ directory. Both are optional. Additional supporting files may be included inside a Skill directory where they are required by that Skill, but they do not replace any required item above.

The repository contains example_submission_structure/ with this same layout. That directory is a starting copy, not the submission itself. Copy it to solution/ at the repository root, then replace the sample text with the team’s own English deliverables and replace presentation.mp4 with the team’s video. solution/ is the working directory used by make play and by the validation command below. It is not part of the cloned repository. When the files are ready, package a ZIP whose top-level directory is that filled-in solution/.

Required contents
manifest.json
Identifies the team and controls how JiuwenSwarm runs the submission. It must contain a real team name, a submission name, a supported mode, and any instruction required by the team’s design. The instruction and other natural-language values must be written in English.

{
  "team": "your-team-name",
  "name": "your-submission-name",
  "mode": "agent",
  "instruction": ""
}
your-team-name in that sample is a placeholder. A blank team name and this sample value are invalid. Local validation rejects both. Replace your-team-name with the team’s real name before submitting.

mode must be agent. Only JiuwenSwarm 0.2.4b3 in single-agent mode may be used. "mode": "team" is prohibited: the JiuwenSwarm team mode must not be used, and a submission that requires multi-agent team execution is invalid. A blank or placeholder team name is also invalid. Here team refers only to the prohibited JiuwenSwarm run mode, not to the people who make up a participating team.

README.md
Identifies the submission and summarises the submitted Skills. It must be written in English.

design/skills_design.md
Explains the purpose of each Skill, how the Skills divide responsibilities, what information each Skill uses, and how their outputs are combined into a decision. It must be written in English.

design/decision_report.md
Explains the team’s overall decision approach, the public information and in-run feedback on which the approach relies, the principal risks, and how the design is intended to generalise beyond the development validation dataset. It must be written in English.

The two design/ documents are scored deliverables, not administrative paperwork. They do not affect the automated document design quality component, which is scored from the Skills themselves; instead, they are an important basis for the expert review in Stage 2 (30% of the weighted final score for the top ten teams), where reviewers watch presentation.mp4 and read the design documents together with the design quality of the Skills. Write them accurately and specifically for the Skills as submitted, and keep them consistent with those Skills. See Competition rules and fair play for how the final score is composed.

presentation.mp4
An English video from the team. Every final ZIP includes this file inside solution/. It is required for every team. The preliminary package used to request an API key does not include it. The video answers all five questions below, in this order:

How did you think while designing the Skills? Describe the reasoning, not only the finished structure.

While debugging your submission, what did you find in the logs of an earlier version that was worth improving, and how did you change it in a later version?

Why did you use scripts or reference files in the Skills, or why did you not use them?

How general and robust are your Skills? If the environment settings change, how well can the agent adapt?

What did this competition lead you to think about the relationship between an agent and agent Skills? What do Skills add for an agent, and where do they fall short?

The video is at most ten minutes long. There is no minimum length. After these five topics, teams are encouraged to share anything else they want reviewers to hear.

A person on camera is enough. Slides are not required. To meet the upload size limit, teams may reduce the video resolution. The video must keep its original playback speed.

A final submission without presentation.mp4 is invalid. For a team that reaches Stage 2, reviewers watch this file with the design/ documents and the Skills.

skills/<skill-name>/SKILL.md
Contains the instructions for one Skill. The file must begin with valid YAML front matter containing at least name and description fields, followed by the Skill instructions.

---
name: skill-name
description: What this Skill decides, and when the agent should use it.
---

Replace this text with the Skill instructions.
All deliverables must be written entirely in English. This includes every Skill’s front-matter description and instructions, and any supporting natural-language text included inside a Skill directory for the agent to read or use. A deliverable written in any other language, in whole or in part, is not accepted and may make the submission invalid. The spoken presentation in presentation.mp4 must also be in English.

Invalid submissions
The following are examples of an invalid final submission:

the ZIP does not contain a top-level solution/ directory;

manifest.json, README.md, or presentation.mp4 is missing;

the design/ directory is missing, or either required design document is missing;

the skills/ directory is missing;

no Skill directory contains a SKILL.md file;

a Skill’s SKILL.md file is missing required front matter;

the manifest contains a placeholder team name or unsupported run mode;

the manifest sets "mode": "team", omits mode, or sets any mode other than "mode": "agent";

a Skill or design document requires JiuwenSwarm team mode or any JiuwenSwarm version other than 0.2.4b3;

any deliverable is written wholly or partly in a language other than English — including the manifest.json instruction, README.md, the spoken presentation in presentation.mp4, either design document, a SKILL.md file, or supporting natural-language text inside a Skill directory.

Missing folders or files will not be supplied by the organisers. Teams should extract the final ZIP into a clean directory and inspect the resulting structure before submitting it.

Local validation
The participation repository provides a validation command:

uv run python -m career_sim_runner validate --submission solution
This command checks the submission directory only. It does not contact JiuwenSwarm, so a stopped instance does not fail the command or change its exit code.

It checks the complete required file and folder structure of the final submission: manifest.json, README.md, presentation.mp4, the design/ directory with both design/skills_design.md and design/decision_report.md, the skills/ directory, and at least one skills/*/SKILL.md. It also checks the manifest fields and each SKILL.md file’s front matter, and reports each missing required item by name. mode must be agent. "mode": "team", a missing mode, or any other mode fails the command. A blank team name and the sample value your-team-name also fail the command. An empty presentation.mp4 fails the command. The video shipped in example_submission_structure/ is an empty placeholder, so validation fails until that file is replaced with the team’s video.

make play may run a local game when presentation.mp4 is not yet present. This validation command still requires that file, because it checks the final submission.

Passing local validation does not waive any other requirement in this document. The command checks that required items are present and that mode is agent. It does not certify their contents. In particular, participants must themselves confirm that the submission was tested with JiuwenSwarm 0.2.4b3, and that every deliverable — manifest.json instruction, README.md, the spoken presentation in presentation.mp4, both design documents, and every Skill — is written entirely in English. The final archive must satisfy the complete requirements above even if a local check does not inspect every document or condition.

Revised, duplicate, and superseded versions
Teams may submit a revised version of their work before the relevant submission deadline. How versions are treated for scoring is defined in Competition rules and fair play and summarised here:

Important

The competition week is 26 October 2026 through 1 November 2026 (UK time, GMT, UTC+0). Scores are collected at 24:00 on 27 October, at 24:00 on 30 October, and at 24:00 on 1 November, then released once each batch has been scored. A batch ordinarily takes one or two days. When many teams submit, it takes longer, because each version is a full simulation run three times.

An evaluated version receives an automated score: 80% live play (the mean of three runs’ quantitative_score), 10% document design quality, and 10% token efficiency. competition_partial_score is quantitative_score × 0.7 and is not that live play score. See Competition rules and fair play.

If you submit more than one version before a cutoff, only the latest version that has not yet been scored is evaluated. Earlier unscored versions are superseded and receive no score.

If a submitted version is content-identical to a version that has already been scored, it will not be scored again. Reformatting, renaming, repackaging, or changing only the identifying metadata does not create a distinct version. The automated score already issued for that work carries over.

Your team’s Stage 1 score is the highest valid automated version score issued to your team across all score releases. A later version that scores lower does not replace an earlier higher automated score.

At the end of Stage 1, the top ten teams by Stage 1 score advance to Stage 2 expert review. Only their final competition score is then calculated as 70% Stage 1 score plus 30% expert review score; teams ranked 11th or below receive no expert review score and no weighted final score. In the expert review, the presentation.mp4 already in the ZIP, the design/ documents, and the design quality of the Skills are the basis for judgement.

See Competition rules and fair play for the binding rules on evaluation, duplicate and superseded submissions, and invalid submissions.

Career Survival Agent
A warm welcome to everyone joining the TechArena Career Simulation! 👾🥳

This is the official documentation for the competition. We are here to help you and make things clear and easy to understand. However, if you still have questions unsolved after reading this instruction, please don’t hesitate to reach out to us in the discord channel (link: https://discord.gg/Ds4JC3gJjj), we will reply during work time.

Career Survival Agent is a long-horizon workplace simulation for AI agents. The agent acts as a newly hired engineer on a product research and development team. A complete run lasts 48 simulated months. During that period, the agent must respond to workplace events, allocate quarterly resources and maintain dimensions like output, wealth and beyond within sustainable limits.

Participants develop an agent with JiuwenSwarm and one or more Skills. The objective is to complete the 48-month simulation and obtain the strongest overall career outcome available under the official scoring method.

Competition at a glance
Item

Requirement

Simulation

One run lasts 48 simulated months. See Public handbook, Public rules, and Failure and endings for the published game information.

Agent platform

JiuwenSwarm 0.2.4b3 exactly. See Competition packages.

Run mode

Single-agent mode only: "mode": "agent". JiuwenSwarm team mode is prohibited. This restricts the JiuwenSwarm execution mode, not the number of people in a participating team.

Deliverables language

All deliverables must be written entirely in English, including README.md, the design documents, the manifest.json instruction, the spoken presentation in presentation.mp4, and every Skill.

Official evaluation

Evaluation has two stages. In Stage 1, scores are released twice during the competition week and once after it ends; a version’s automated score is 80% live play (the mean of three runs), 10% document design quality of the Skills, and 10% token efficiency, and a team’s Stage 1 score is its highest valid automated version score. At the end of Stage 1, the top ten teams advance to Stage 2 expert review, where the final score is 70% Stage 1 score and 30% expert review score; teams outside the top ten receive no weighted final score. Every final ZIP includes an English presentation.mp4. In the expert review, that presentation, the design/ documents, and the design quality of the Skills are the basis for judgement. Content-identical versions are not scored again; the earlier score carries over. See Competition rules and fair play.

Binding rules

Competition rules and fair play defines the permitted interfaces, prohibited conduct, and consequences of an invalid submission. Submission requirements defines the required preliminary and final submission structure.

Before beginning development, participants must read Competition rules and fair play and Submission requirements. Questions about the interpretation of these documents go to the Discord channel (https://discord.gg/Ds4JC3gJjj) before the relevant action is taken. The organisers’ interpretation is final. Silence in the documentation must not be treated as permission.

Participation process
Read the rules and prepare a preliminary submission. Read Competition rules and fair play and Submission requirements, then submit the preliminary design and Skills documents described in Competition API key on the official competition website, https://techarena-uk.hydro.ac/. This preliminary submission is used only to verify genuine participation. It is not scored.

Receive the competition API key. After the organisers verify the preliminary submission, the competition API key is issued by email. The key is restricted to the designated competition model, a maximum credit of USD 50, and the competition week only. Configure API_BASE, API_KEY, and MODEL_NAME only; OpenRouter hosting routes for official scoring are controlled by the organisers (see Competition API key).

Set up and develop. Follow Quickstart to install the official participation repository, configure JiuwenSwarm and the MCP server, and run a local game. Use Competition packages and Configuring the track MCP server as reference while developing.

Design against the public game information. Base decisions on Public handbook, Public rules, and the information returned through the official interface during a run. Failure and endings explains the published failure directions and ending dimensions.

Validate and submit. Validate the final submission structure locally and submit the final ZIP archive according to Submission requirements before 24:00 UK time (GMT, UTC+0) on 1 November 2026. Interim scoring cutoffs are 24:00 on 27 October and 24:00 on 30 October; see Competition rules and fair play.

Competition software
The agent platform is JiuwenSwarm 0.2.4b3, used in single-agent mode. Two PyPI packages provide the simulation:

career-emulator-engine is the simulation engine. It provides the command line interface and the MCP server used by agents.

career-emulator-techarena is the data package. It contains the public development validation dataset used for local development.

The platform, packages, installation commands, and dataset boundaries are described in Competition packages and Quickstart. Participants interact with the simulation through the public CLI and MCP interfaces only. Reading or extracting the internal package data or rules is prohibited; see Competition rules and fair play.

