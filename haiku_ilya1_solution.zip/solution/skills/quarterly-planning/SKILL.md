---
name: quarterly-planning
description: "Plans the quarter-end phase: how to spend up to 3 Energy points and which main action to take or skip. Use it whenever observe shows the quarterly action phase or lists Energy actions. It uses only the published action effects, cleans up hidden risk after warnings, and adapts to the state and to how far the run has progressed."
---

# Quarterly Planning

At the end of each quarter you get 3 Energy points (unused points are lost) and may take one main action or none. Follow the actions, costs and effects that the interface actually lists on screen; they can differ from this page. The effects below are the published ones. Anything else you learn from feedback.

## Published effects
Energy actions:
- High-intensity work (2): Output up, Health down, Dignity down. If its listed effects also raise hidden risk (check the screen), never use it.
- Skill learning (2): Skill up, Health down.
- Network maintenance (1): Network up, Dignity up.
- Defuse legacy risk (2): lowers hidden risk (see the listed effects).
- Mental recovery (1): Dignity up.
- Health recovery (1): Health up.
- Prepare report materials (1): Output up, Dignity up.

Main actions:
- Apply for a key project: Output, Skill, Network up.
- Report results to your manager: Output, Network, Dignity up.
- Fight for resources: Output, Network up.
- Apply for rotation: Skill, Network up.
- Showcase results: Output, Dignity up.
- Build a mentorship: Skill, Network up.
- Repair a key relationship: Network, Dignity up.
- Lay low and reduce risk: Health up; its listed effects show whether it also lowers hidden risk.

## Steps
1. **Diagnose.** Apply the risk rules from `career-survival-core`. Name the dimension under pressure (if any), the worst risk flag in your notes since the previous quarter-end (including this month; a missing flag counts as `none`), and whether a six-month review is close.
2. **Risk clean-up first.**
   - `risk:serious` since the last quarter-end: take Defuse legacy risk. This is not optional. Lay low and reduce risk is the main action only when a blow-up has happened or Health is 3 or below (see step 6).
   - `risk:mild` alone never triggers a clean-up in this version.
   - A blow-up message has happened: take Defuse legacy risk AND the main action Lay low and reduce risk every quarter until two quarters in a row show no risk comment.
   - The clean-up comes first and uses its Energy. In a clean-up quarter the one leftover point goes to Health recovery if Health is 3 or below, otherwise to Prepare report materials.
3. **Cover other urgent needs.**
   - Health 3 or below: Health recovery, after any clean-up. Take it again only if Health is still 3 or below after you observe, at most two uses per quarter. A second use replaces Prepare report materials, never Network maintenance.
   - Dignity under pressure: Mental recovery, Network maintenance or Prepare report materials; consider "Repair a key relationship" or "Showcase results".
   - Network is 0 or 1: Network maintenance and a main action that raises Network.
   - Never buy a recovery for a statistic that is already at 10.
4. **Spend the rest on growth, with Output and Network first.** The default quarter is Prepare report materials + Network maintenance + one more 1-point action (Health recovery if Health is below 10, otherwise a second Prepare report materials or Network maintenance), with the main action from step 6. Until you have your first promotion, every quarter that is not a risk clean-up quarter keeps both Prepare report materials and Network maintenance. After a C or D review, keep them too. A 2-point action (Skill learning, High-intensity work) is never added in a quarter where Prepare report materials and Network maintenance are both kept.
5. **Use Skill learning and High-intensity work carefully.** They are not part of the default quarter in step 4. Use them only when Health and Dignity are not under pressure, no risk flag is `serious`, the listed effects do not raise hidden risk, and Output and Network are not both weak. If Health is below 10 afterwards, recover it in the same or the next quarter. Do not repeat the same Health-costing or Dignity-costing action every quarter. When Skill is the weakest dimension, "Apply for rotation" or "Build a mentorship" as the main action costs no Energy.
6. **Choose the main action to fit the need.** Use the first rule that applies:
   - A blow-up has happened, or Health is 3 or below: "Lay low and reduce risk". A serious flag alone does not select it. This rule outranks the Output report rule below.
   - Output is 3 or below at a quarter-end in month 3, 9, 15, 21, 27, 33, 39 or 45 (the quarter just before a review): "Report results to your manager".
   - From level 2 on: "Apply for rotation" (Skill and Network up). Skill is a promotion factor and rotation is the strongest free Skill action. Do not skip it because Skill looks high: Skill is usually the top stat from level 2 on.
   - At level 1: "Apply for a key project".
   - Nothing fits: take no main action.
7. **Use the Energy.** Order within the quarter is fixed: (1) risk clean-up, (2) Health 3 or below recovery, (3) other urgent needs, (4) growth. Spend all 3 points unless a remaining action would hurt a dimension that is under pressure. An action may be taken twice in a quarter if it is still listed. Do not repeat a plan that the statistics show did not work: if a statistic you paid for did not rise, pay for a different one (Skill learning if Health and Dignity are safe, otherwise a recovery that is below 10). Use "Reserve energy" only if no listed action helps.
8. Execute the actions one at a time through `take_action`, then `observe`, and revise the rest of the plan if something changed. Notes stay under 300 characters and keep the core format, for example: `Q5 M15 L2 H6 D8 N4 O3 | risk:none | plan: report + network + health, main: key project`.

## Final quarters (quarter-ends in months 45 and 48)
Choose actions whose effect lands before month 48. Skip slow investments that cannot pay off, and do not run Health or Dignity down at the end. In these two quarter-ends, in this order: Health recovery once if Health is below 10 (repeat it only while Health is 3 or below), then Mental recovery once if Dignity is below 10, then any risk clean-up that applies, then Network maintenance with what is left. Do not buy Skill learning. The Health 3 or below rule still applies in these quarters. Main action there: Lay low and reduce risk if a blow-up has happened or Health is 3 or below, otherwise "Report results to your manager".

## If the interface differs
Costs, effects or the option list may differ from this page. Follow what the interface shows and use the same diagnose-then-plan logic.
